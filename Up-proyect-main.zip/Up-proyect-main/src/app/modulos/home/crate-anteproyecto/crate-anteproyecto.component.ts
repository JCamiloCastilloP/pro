import { Component } from '@angular/core';

@Component({
  selector: 'app-crate-anteproyecto',
  templateUrl: './crate-anteproyecto.component.html',
  styleUrls: ['./crate-anteproyecto.component.sass']
})
export class CrateAnteproyectoComponent {

}
