import { Component } from '@angular/core';

@Component({
  selector: 'app-ver-proyecto',
  templateUrl: './ver-proyecto.component.html',
  styleUrls: ['./ver-proyecto.component.sass']
})
export class VerProyectoComponent {

}
