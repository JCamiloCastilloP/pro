import { Component } from '@angular/core';

@Component({
  selector: 'app-lista-items',
  templateUrl: './lista-items.component.html',
  styleUrls: ['./lista-items.component.sass']
})
export class ListaItemsComponent {

}
